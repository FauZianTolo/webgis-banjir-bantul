<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Peta Monitoring - Semua Laporan') }}
        </h2>
    </x-slot>

    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />

    <style>
        .map-admin-container {
            height: calc(100vh - 200px);
            width: 100%;
        }

        .info-box {
            background: white;
            padding: 1rem;
            margin-bottom: 1rem;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        /* Modal Styling */
        .modal-image-viewer {
            display: none;
            position: fixed;
            z-index: 9999;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.9);
            backdrop-filter: blur(4px);
        }

        .modal-image-content {
            position: relative;
            margin: auto;
            padding: 0;
            width: 90%;
            max-width: 1200px;
            top: 50%;
            transform: translateY(-50%);
        }

        .modal-image-viewer img {
            width: 100%;
            height: auto;
            max-height: 85vh;
            object-fit: contain;
            border-radius: 8px;
        }

        .modal-close-btn {
            position: absolute;
            top: -15px;
            right: -15px;
            color: #fff;
            background: #ef4444;
            font-size: 32px;
            font-weight: bold;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            border: 3px solid white;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
            z-index: 10000;
        }

        .modal-close-btn:hover {
            background: #dc2626;
            transform: scale(1.1);
        }
    </style>

    <div class="py-6">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            <div class="info-box">
                <div class="flex items-center justify-between">
                    <div>
                        <h4 class="text-lg font-bold">Peta Monitoring Laporan Banjir</h4>
                        <p class="text-sm text-gray-600 mt-1">
                            <span class="text-yellow-600"><i class="fas fa-circle"></i> Pending: {{ $laporan->where('status', 'pending')->count() }}</span> |
                            <span class="text-green-600"><i class="fas fa-circle"></i> Verified: {{ $laporan->where('status', 'verified')->count() }}</span> |
                            <span class="text-red-600"><i class="fas fa-circle"></i> Rejected: {{ $laporan->where('status', 'rejected')->count() }}</span>
                        </p>
                    </div>
                    <a href="{{ route('admin.laporan.index') }}" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                        <i class="fas fa-list"></i> Kelola Laporan
                    </a>
                </div>
            </div>

            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="map-admin-container" id="map"></div>
            </div>

        </div>
    </div>

    <!-- ⭐ MODAL IMAGE VIEWER -->
    <div id="imageModal" class="modal-image-viewer">
        <div class="modal-image-content">
            <span class="modal-close-btn" onclick="closeImageModal()">&times;</span>
            <img id="modalImage" src="" alt="Foto Laporan">
        </div>
    </div>

    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script>
        // ⭐⭐⭐ MODAL IMAGE FUNCTIONS ⭐⭐⭐
        function openImageModal(src) {
            event.stopPropagation();
            event.preventDefault();
            document.getElementById('modalImage').src = src;
            document.getElementById('imageModal').style.display = 'block';
            document.body.style.overflow = 'hidden';
        }

        function closeImageModal() {
            document.getElementById('imageModal').style.display = 'none';
            document.body.style.overflow = '';
        }

        // Close on ESC key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') closeImageModal();
        });

        // Close on background click
        document.getElementById('imageModal').addEventListener('click', function(e) {
            if (e.target === this) closeImageModal();
        });

        // ⭐⭐⭐ MAP INITIALIZATION ⭐⭐⭐
        document.addEventListener('DOMContentLoaded', function() {
            var map = L.map('map').setView([-7.9500, 110.3500], 11);

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap contributors',
                maxZoom: 18,
            }).addTo(map);

            // Load zona kerawanan
            fetch('/storage/geojson/bantul_dummy.geojson')
                .then(response => response.json())
                .then(data => {
                    L.geoJSON(data, {
                        style: function(feature) {
                            var fillColor = feature.properties.ZONA === 'Tinggi' ? '#ff0000' :
                                           feature.properties.ZONA === 'Sedang' ? '#ffff00' : '#00ff00';
                            return { fillColor: fillColor, fillOpacity: 0.3, color: '#000', weight: 1 };
                        }
                    }).addTo(map);
                });

            // Icon berdasarkan status
            var pendingIcon = L.icon({
                iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-yellow.png',
                shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
                iconSize: [25, 41],
                iconAnchor: [12, 41],
                popupAnchor: [1, -34]
            });

            var verifiedIcon = L.icon({
                iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png',
                shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
                iconSize: [25, 41],
                iconAnchor: [12, 41],
                popupAnchor: [1, -34]
            });

            var rejectedIcon = L.icon({
                iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
                shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
                iconSize: [25, 41],
                iconAnchor: [12, 41],
                popupAnchor: [1, -34]
            });

            // ⭐⭐⭐ Add markers dengan FOTO ⭐⭐⭐
            var laporanData = @json($laporan);

            laporanData.forEach(function(item) {
                var icon = item.status === 'pending' ? pendingIcon :
                          item.status === 'verified' ? verifiedIcon : rejectedIcon;

                var statusColor = item.status === 'pending' ? '#fef3c7' :
                                 item.status === 'verified' ? '#d1fae5' : '#fee2e2';
                var statusTextColor = item.status === 'pending' ? '#92400e' :
                                     item.status === 'verified' ? '#065f46' : '#991b1b';
                var statusText = item.status === 'pending' ? 'PENDING' :
                                item.status === 'verified' ? 'VERIFIED' : 'REJECTED';

                var marker = L.marker([item.latitude, item.longitude], {icon: icon}).addTo(map);

                // ⭐ BUILD POPUP DENGAN FOTO
                var popupContent = '<div style="min-width: 260px; max-width: 320px;">' +
                    '<h6 style="font-weight: bold; margin-bottom: 10px; font-size: 14px;">Laporan #' + item.id + '</h6>';

                // ⭐ TAMBAHKAN FOTO JIKA ADA (FIX: HAPUS '_blank')
                if (item.foto) {
                    popupContent += '<div style="margin-bottom: 12px;">' +
                        '<img src="/uploads/laporan/' + item.foto + '" ' +
                        'alt="Foto Kejadian" ' +
                        'style="width: 100%; max-height: 180px; object-fit: cover; border-radius: 8px; cursor: pointer;" ' +
                        'onclick="openImageModal(\'/uploads/laporan/' + item.foto + '\')">' +
                        '<p style="font-size: 10px; color: #666; margin-top: 4px; text-align: center;">Klik untuk memperbesar</p>' +
                        '</div>';
                }

                popupContent += '<p style="margin: 6px 0;"><strong>Status:</strong> ' +
                    '<span style="background: ' + statusColor + '; color: ' + statusTextColor + '; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: bold;">' +
                    statusText +
                    '</span></p>' +
                    '<p style="margin: 6px 0;"><strong>Lokasi:</strong> ' + item.kecamatan + ', ' + item.desa + '</p>' +
                    '<p style="margin: 6px 0;"><strong>Kedalaman:</strong> <span style="font-weight: bold; color: ' +
                    (item.kedalaman_cm >= 70 ? '#991b1b' : item.kedalaman_cm >= 40 ? '#92400e' : '#1e40af') + ';">' +
                    item.kedalaman_cm + ' cm</span></p>' +
                    '<p style="margin: 6px 0;"><strong>Pelapor:</strong> ' + item.nama_pelapor + '</p>' +
                    '<p style="margin: 6px 0;"><strong>No. Telp:</strong> ' + (item.no_telp || '-') + '</p>' +
                    '<p style="margin: 6px 0;"><strong>Waktu:</strong> ' + new Date(item.waktu_laporan).toLocaleString('id-ID') + '</p>' +
                    '<p style="margin-top: 8px; font-size: 12px; color: #666; line-height: 1.4;">' + item.deskripsi + '</p>' +
                    '</div>';

                marker.bindPopup(popupContent, { maxWidth: 340 });
            });

            console.log('✅ Total laporan dimuat:', laporanData.length);
        });
    </script>
</x-app-layout>
