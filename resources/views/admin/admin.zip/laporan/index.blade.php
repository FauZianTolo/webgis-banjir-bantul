<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Verifikasi Laporan Banjir') }}
        </h2>
    </x-slot>

    <style>
        .stats-mini {
            background: white;
            border-radius: 10px;
            padding: 1rem;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .stats-mini h3 {
            font-size: 2rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
        }

        .badge-status {
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: 600;
        }
    </style>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            @if (session('success'))
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                    {{ session('success') }}
                </div>
            @endif

            <!-- Stats Cards -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div class="stats-mini" style="border-left: 4px solid #f59e0b;">
                    <h3 class="text-yellow-600">{{ $pending }}</h3>
                    <p class="text-gray-600">Pending</p>
                </div>
                <div class="stats-mini" style="border-left: 4px solid #10b981;">
                    <h3 class="text-green-600">{{ $verified }}</h3>
                    <p class="text-gray-600">Verified</p>
                </div>
                <div class="stats-mini" style="border-left: 4px solid #ef4444;">
                    <h3 class="text-red-600">{{ $rejected }}</h3>
                    <p class="text-gray-600">Rejected</p>
                </div>
            </div>

            <!-- Tabel Laporan -->
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg p-6">
                <h3 class="text-lg font-bold mb-4">
                    <i class="fas fa-list"></i> Daftar Laporan Banjir
                </h3>

                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Foto</th>
                                <!-- ⭐ TAMBAH -->
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tanggal</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Pelapor</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Lokasi</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Kedalaman
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Deskripsi
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            @forelse($laporanList as $item)
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                        {{ $item->id }}
                                    </td>

                                    <!-- ⭐ KOLOM FOTO -->
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        @if ($item->foto)
                                            <img src="{{ asset('uploads/laporan/' . $item->foto) }}" alt="Foto"
                                                class="rounded cursor-pointer hover:opacity-75"
                                                style="width: 50px; height: 50px; object-fit: cover;"
                                                onclick="openImageModal('{{ asset('uploads/laporan/' . $item->foto) }}')"
                                                title="Klik untuk memperbesar">
                                        @else
                                            <span class="text-gray-400 text-xs">-</span>
                                        @endif
                                    </td>

                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        {{ $item->waktu_laporan->format('d/m/Y H:i') }}
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-900">
                                        {{ $item->nama_pelapor }}<br>
                                        <span class="text-gray-500 text-xs">{{ $item->no_telp }}</span>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-900">
                                        <strong>{{ $item->kecamatan }}</strong><br>
                                        <span class="text-gray-500">{{ $item->desa }}</span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span
                                            class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full
                    @if ($item->kedalaman_cm >= 70) bg-red-100 text-red-800
                    @elseif($item->kedalaman_cm >= 40) bg-yellow-100 text-yellow-800
                    @else bg-blue-100 text-blue-800 @endif">
                                            {{ $item->kedalaman_cm ?? 0 }} cm
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-500">
                                        {{ Str::limit($item->deskripsi, 50) }}
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        @if ($item->status === 'pending')
                                            <span
                                                class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                                                Pending
                                            </span>
                                        @elseif($item->status === 'verified')
                                            <span
                                                class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                                Verified
                                            </span>
                                        @else
                                            <span
                                                class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                                                Rejected
                                            </span>
                                        @endif
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        @if ($item->status === 'pending')
                                            <form action="{{ route('admin.laporan.verify', $item->id) }}"
                                                method="POST" class="inline mr-2">
                                                @csrf
                                                <button type="submit" class="text-green-600 hover:text-green-900">
                                                    <i class="fas fa-check-circle"></i> Verifikasi
                                                </button>
                                            </form>

                                            <form action="{{ route('admin.laporan.reject', $item->id) }}"
                                                method="POST" class="inline">
                                                @csrf
                                                <button type="submit" class="text-red-600 hover:text-red-900">
                                                    <i class="fas fa-times-circle"></i> Tolak
                                                </button>
                                            </form>
                                        @elseif($item->status === 'rejected')
                                            <form action="{{ route('admin.laporan.destroyRejected', $item->id) }}"
                                                method="POST" class="inline"
                                                onsubmit="return confirm('Yakin ingin menghapus laporan ini?');">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="text-red-600 hover:text-red-900">
                                                    <i class="fas fa-trash"></i> Hapus
                                                </button>
                                            </form>
                                        @else
                                            <span class="text-gray-400">-</span>
                                        @endif
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="9" class="px-6 py-4 text-center text-gray-500">
                                        Belum ada laporan
                                    </td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Quick Link -->
            <div class="mt-6">
                <a href="{{ route('admin.peta') }}"
                    class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                    <i class="fas fa-map"></i> Lihat Peta Semua Laporan
                </a>
            </div>

        </div>
    </div>
    <!-- ⭐ MODAL IMAGE VIEWER -->
    <x-image-modal />
</x-app-layout>
