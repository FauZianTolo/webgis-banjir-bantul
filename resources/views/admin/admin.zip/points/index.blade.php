<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Data Points - Kelola Titik Laporan') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            @if (session('success'))
                <div class="mb-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative">
                    {{ session('success') }}
                </div>
            @endif

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">

                    <div class="mb-4 flex justify-between items-center">
                        <h3 class="text-lg font-bold">📍 Daftar Laporan Terverifikasi</h3>
                        <span class="text-sm text-gray-600">Total: {{ $laporan->total() }} laporan</span>
                    </div>

                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Foto
                                    </th> <!-- ⭐ TAMBAH -->
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Waktu
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Lokasi
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                                        Koordinat</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                                        Kedalaman</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Pelapor
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Aksi
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                @forelse($laporan as $item)
                                    <tr>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                            {{ $item->id }}
                                        </td>

                                        <!-- ⭐ KOLOM FOTO -->
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            @if ($item->foto)
                                                <img src="{{ asset('uploads/laporan/' . $item->foto) }}" alt="Foto"
                                                    class="rounded-lg cursor-pointer hover:opacity-75 transition"
                                                    style="width: 60px; height: 60px; object-fit: cover;"
                                                    onclick="openImageModal('{{ asset('uploads/laporan/' . $item->foto) }}')"
                                                    title="Klik untuk memperbesar">
                                            @else
                                                <span class="text-gray-400 text-xs">Tidak ada foto</span>
                                            @endif
                                        </td>

                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            {{ $item->waktu_laporan->format('d/m/Y H:i') }}
                                        </td>
                                        <td class="px-6 py-4 text-sm text-gray-900">
                                            <strong>{{ $item->kecamatan }}</strong><br>
                                            <span class="text-gray-500">{{ $item->desa }}</span>
                                        </td>
                                        <td class="px-6 py-4 text-sm text-gray-500">
                                            {{ number_format($item->latitude, 6) }},<br>
                                            {{ number_format($item->longitude, 6) }}
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <span
                                                class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full
                    @if ($item->kedalaman_cm >= 70) bg-red-100 text-red-800
                    @elseif($item->kedalaman_cm >= 40) bg-yellow-100 text-yellow-800
                    @else bg-blue-100 text-blue-800 @endif">
                                                {{ $item->kedalaman_cm ?? 0 }} cm
                                            </span>
                                        </td>
                                        <td class="px-6 py-4 text-sm text-gray-900">
                                            {{ $item->nama_pelapor }}<br>
                                            <span class="text-gray-500">{{ $item->no_telp }}</span>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                            <a href="{{ route('admin.points.edit', $item->id) }}"
                                                class="text-blue-600 hover:text-blue-900 mr-3">
                                                <i class="fas fa-edit"></i> Edit
                                            </a>

                                            <form action="{{ route('admin.points.destroy', $item->id) }}"
                                                method="POST" class="inline"
                                                onsubmit="return confirm('Yakin ingin menghapus data ini?');">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="text-red-600 hover:text-red-900">
                                                    <i class="fas fa-trash"></i> Hapus
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="8" class="px-6 py-4 text-center text-gray-500">
                                            Belum ada data laporan terverifikasi
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>

                        <!-- ⭐ MODAL untuk MEMPERBESAR GAMBAR -->
                        <div id="imageModal"
                            class="hidden fixed inset-0 bg-black bg-opacity-75 z-50 flex items-center justify-center"
                            onclick="closeImageModal()">
                            <div class="relative max-w-4xl max-h-screen p-4">
                                <button onclick="closeImageModal()"
                                    class="absolute top-2 right-2 text-white text-3xl font-bold hover:text-gray-300">
                                    &times;
                                </button>
                                <img id="modalImage" src="" alt="Foto Besar"
                                    class="max-w-full max-h-screen rounded-lg">
                            </div>
                        </div>

                        <script>
                            function openImageModal(src) {
                                event.stopPropagation();
                                document.getElementById('modalImage').src = src;
                                document.getElementById('imageModal').classList.remove('hidden');
                            }

                            function closeImageModal() {
                                document.getElementById('imageModal').classList.add('hidden');
                            }
                        </script>
                    </div>

                    <div class="mt-4">
                        {{ $laporan->links() }}
                    </div>

                </div>
            </div>
        </div>
    </div>
    </table>

    <div class="mt-4">
        {{ $laporan->links() }}
    </div>

    <!-- ⭐ MODAL IMAGE VIEWER -->
    <x-image-modal />
</x-app-layout>
