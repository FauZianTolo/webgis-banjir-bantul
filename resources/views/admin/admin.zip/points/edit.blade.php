<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Edit Data Laporan #') }}{{ $laporan->id }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">

            @if($errors->any())
            <div class="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative">
                <strong>Error!</strong>
                <ul class="mt-2">
                    @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
            @endif

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">

                    <form action="{{ route('admin.points.update', $laporan->id) }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

                            <!-- Nama Pelapor -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    Nama Pelapor <span class="text-red-500">*</span>
                                </label>
                                <input type="text" name="nama_pelapor"
                                       value="{{ old('nama_pelapor', $laporan->nama_pelapor) }}"
                                       class="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                                       required>
                            </div>

                            <!-- No. Telepon -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    No. Telepon
                                </label>
                                <input type="text" name="no_telp"
                                       value="{{ old('no_telp', $laporan->no_telp) }}"
                                       class="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                            </div>

                            <!-- Kecamatan -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    Kecamatan <span class="text-red-500">*</span>
                                </label>
                                <select name="kecamatan"
                                        class="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                                        required>
                                    <option value="">-- Pilih Kecamatan --</option>
                                    @foreach(['Banguntapan', 'Bantul', 'Bambanglipuro', 'Dlingo', 'Imogiri', 'Jetis', 'Kasihan', 'Kretek', 'Pajangan', 'Pandak', 'Piyungan', 'Pleret', 'Pundong', 'Sanden', 'Sedayu', 'Sewon', 'Srandakan'] as $kec)
                                    <option value="{{ $kec }}" {{ old('kecamatan', $laporan->kecamatan) == $kec ? 'selected' : '' }}>
                                        {{ $kec }}
                                    </option>
                                    @endforeach
                                </select>
                            </div>

                            <!-- Desa -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    Desa/Kelurahan
                                </label>
                                <input type="text" name="desa"
                                       value="{{ old('desa', $laporan->desa) }}"
                                       class="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                            </div>

                            <!-- Latitude -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    Latitude <span class="text-red-500">*</span>
                                </label>
                                <input type="number" step="0.000001" name="latitude"
                                       value="{{ old('latitude', $laporan->latitude) }}"
                                       class="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                                       required>
                            </div>

                            <!-- Longitude -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    Longitude <span class="text-red-500">*</span>
                                </label>
                                <input type="number" step="0.000001" name="longitude"
                                       value="{{ old('longitude', $laporan->longitude) }}"
                                       class="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                                       required>
                            </div>

                            <!-- Kedalaman -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    Kedalaman Air (cm)
                                </label>
                                <input type="number" name="kedalaman_cm"
                                       value="{{ old('kedalaman_cm', $laporan->kedalaman_cm) }}"
                                       class="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                            </div>

                            <!-- Waktu Laporan -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    Waktu Laporan <span class="text-red-500">*</span>
                                </label>
                                <input type="datetime-local" name="waktu_laporan"
                                       value="{{ old('waktu_laporan', $laporan->waktu_laporan->format('Y-m-d\TH:i')) }}"
                                       class="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                                       required>
                            </div>

                        </div>

                        <!-- Deskripsi -->
                        <div class="mt-6">
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                Deskripsi Kejadian <span class="text-red-500">*</span>
                            </label>
                            <textarea name="deskripsi" rows="4"
                                      class="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                                      required>{{ old('deskripsi', $laporan->deskripsi) }}</textarea>
                        </div>

                        <!-- Foto -->
                        <div class="mt-6">
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                Foto Kejadian
                            </label>

                            @if($laporan->foto)
                            <div class="mb-3">
                                <p class="text-sm text-gray-600 mb-2">Foto saat ini:</p>
                                <img src="{{ asset('uploads/laporan/' . $laporan->foto) }}"
                                     alt="Foto"
                                     class="w-48 h-48 object-cover rounded-lg">
                            </div>
                            @endif

                            <input type="file" name="foto" accept="image/*"
                                   class="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                            <p class="mt-1 text-sm text-gray-500">Biarkan kosong jika tidak ingin mengubah foto</p>
                        </div>

                        <!-- Buttons -->
                        <div class="mt-6 flex justify-end space-x-3">
                            <a href="{{ route('admin.points.index') }}"
                               class="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
                                Batal
                            </a>
                            <button type="submit"
                                    class="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700">
                                <i class="fas fa-save"></i> Simpan Perubahan
                            </button>
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>
</x-app-layout>
